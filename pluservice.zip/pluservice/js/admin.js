
function change_tab(pagina) {
  $.ajax({
    type: "post",
    url: "users/admin/pages.php",
    dataType: 'html',
    cache: false,
    data: {
      get_this: pagina,
    },
    success: function (data) {
      if (data != "") {
        $('#tab-wrapper').html("");
        $('#tab-wrapper').html(data);
      }

    },
    error: function () {
      alert('Error while request..! try again');
    }
  });
  return false;
}

//Loads people gradually
function print_humans() {
  show_humans(15);
  setTimeout(function () { show_humans(25) }, 100);
  setTimeout(function () { show_humans(100) }, 250);
  setTimeout(function () { show_humans(0) }, 750);
}

//Loads cities gradually
function print_cities() {
  show_cities(15);
  setTimeout(function () { show_cities(25) }, 100);
  setTimeout(function () { show_cities(100) }, 250);
  setTimeout(function () { show_cities(0) }, 750);
}

//Populates the table with people from the DB
function show_humans(limit) {
  $.ajax({
    type: "post",
    url: "users/admin/functions.php",
    dataType: 'json',
    cache: false,
    data: {
      function: 1,
      limit: limit,
    },
    success: function (returnedData) {
      var table = $('#table_humans').DataTable();
      table.clear();

      var myTableArray = [];
      var result = returnedData;

      for (var i = 0; i < result.length; i++) {
        myTableArray.push([result[i]["id"], result[i]["nome"], result[i]["cognome"], result[i]["city"],
        '<div style="text-align: center;"><i id="' + result[i]["id"] + '" class="fa-solid fa-pen" value = "Modifica" onClick="Javascript:modify_person(this,' + i + ',0)" style="cursor:pointer; color:#00623b"></i></div>',
        '<div style="text-align: center;"><i class="fa-solid fa-user-minus" value = "Rimuovi"  onClick="Javascript:delete_person(this,' + result[i]["id"] + ')" style="cursor:pointer; color:#D8000C;text-align: center;"></i></div>']);
      }

      table.rows.add(myTableArray);
      //table.column(1).visible(false);
      table.draw(false);
    },
    error: function () {
      alert('Error while request..! try again');
    }
  });
}

//Populates the table with cities from the DB
function show_cities(limit) {
  $.ajax({
    type: "post",
    url: "users/admin/functions.php",
    dataType: 'json',
    cache: false,
    data: {
      function: 2,
      limit: limit,
    },
    success: function (returnedData) {
      //console.log(returnedData);

      var table = $('#table_cities').DataTable();
      table.clear();

      var myTableArray = [];
      var result = returnedData;
      for (var i = 0; i < result.length; i++) {
        myTableArray.push([result[i]["id"], result[i]["name"]])
      }

      table.rows.add(myTableArray);
      //table.column(3).visible(false);
      table.draw(false);
    },
    error: function () {
      alert('Error while request..! try again');
    }
  });
}

//Inizialize the Humans Datatable
function init_datatable_humans() {
  $("#table_humans thead tr").addClass("filters").appendTo("#table_humans thead");

  var table = $("#table_humans").DataTable({
    "pageLength": 25,
    "order": [
      [0, "asc"]
    ],
    orderCellsTop: true,
    fixedHeader: true,
    fixedHeader: {
      header: true,
      footer: true
    },
    colReorder: false,
    scrollY: 600,
    scrollCollapse: true,
    scroller: true,
    dom: 'Bfrtip',
    buttons: [
      'copy', 'csv', 'excel', 'pdf', 'print'
    ],

  });
  return table;
}



//Inizialize the Cities Datatable
function init_datatable_cities() {
  $("#table_cities thead tr").addClass("filters").appendTo("#table_cities thead");

  var table = $("#table_cities").DataTable({
    "pageLength": 25,
    "order": [
      [0, "asc"]
    ],
    orderCellsTop: true,
    fixedHeader: true,
    fixedHeader: {
      header: true,
      footer: true
    },
    colReorder: false,
    scrollY: 700,
    scrollCollapse: true,
    scroller: true,
    dom: 'Bfrtip',
    buttons: [
      'copy', 'csv', 'excel', 'pdf', 'print'
    ],

  });
  return table;
}

function add_person() { // da qui poi farai l'aggiunta di una persona
  var name = document.getElementById("add_name").value.trim();
  var surname = document.getElementById("add_surname").value.trim();
  var city = document.getElementById("add_city").value.trim();


  $.ajax({
     url: "users/admin/functions.php",
     method: "POST",
     dataType: "text",
     data: {
        function: 3,
        name: name,
        surname: surname,
        city: city,
     }
  }).done(function (returnedData) {
     change_tab("tab1");

  })
  //table.deleteRow(index);
}

function modify_person(obj, index, action) {
  /*source  "``"
  https://jsfiddle.net/KyleMit/5aaa9cmj/
  https://stackoverflow.com/questions/34259410/how-to-update-an-existing-row-with-html-on-an-existing-jquery-datatables/43522442#43522442
  */

  var table = $('#table_humans').DataTable();
  var idx = table.cell(index, 0).index();
  var data = table.row(idx.row).data();

  //richiesta di modifica di una riga
  if (action == 0) {
     //Se modificando è diverso da -1 allora significa che stiamo modificando un record, è  necessario rimettere i dati a posto
     if (modificando != -1) {
        var idx = table.cell(modificando, 0).index();
        var data = table.row(idx.row).data();
        id = data[0];
        nome = document.getElementById('name_column').getAttribute('data-value');
        cognome = document.getElementById('surname_column').getAttribute('data-value');
        city_name = data[3];
        
        table.row(modificando).data([id, nome, cognome, city_name,
           '<div style="text-align: center;"><i id="' + id + '" class="fa-solid fa-pen" value = "Modifica" onClick="Javascript:modify_person(this,' + modificando + ',0)" style="cursor:pointer; color:#00623b"></i></div>',
           '<div style="text-align: center;"><i class="fa-solid fa-user-minus" value = "Rimuovi"  onClick="Javascript:delete_person(this,' + id + ')" style="cursor:pointer; color:#D8000C;text-align: center;"></i></div>']);
     }
    
     //sets the cells to be modified
     var idx = table.cell(index, 0).index();
     var data = table.row(idx.row).data();
     id = data[0];
     nome = data[1];
     cognome = data[2];
     city_name = data[3];
    
     table.row(index).data([id,
        '<input id="name_column" data-value="' + nome + '" value="' + nome + '" type="text" placeholder="nome">',
        '<input id="surname_column" data-value="' + cognome + '" value="' + cognome + '" type="text" placeholder="nome">',
        city_name,
        '<div style="text-align: center;"><i id="' + data[0] + '" class="fa-solid fa-check" value = "Modifica" onClick="Javascript:modify_person(this,' + index + ',2)" style="cursor:pointer; color:#00623b;font-weight:bolder;font-size:22.5px"></i></div>',/**/
        '<div style="text-align: center;"><i class="fa-solid fa-xmark" value = "Rimuovi"  onClick="Javascript:modify_person(this,' + index + ',1)" style="cursor:pointer; color:#D8000C;text-align: center;font-weight:bolder;font-size:22.5px"></i></div>']);

     modificando = index;
  }
  //annulla modifica
  else if (action == 1) {
     modificando = -1;
     id = data[0];
     nome = document.getElementById('name_column').getAttribute('data-value');
     cognome = document.getElementById('surname_column').getAttribute('data-value');
     city_name = data[3];
     
     table.row(index).data([id, nome, cognome, city_name,
        '<div style="text-align: center;"><i id="' + id + '" class="fa-solid fa-pen" value = "Modifica" onClick="Javascript:modify_person(this,' + index + ',0)" style="cursor:pointer; color:#00623b"></i></div>',
        '<div style="text-align: center;"><i class="fa-solid fa-user-minus" value = "Rimuovi"  onClick="Javascript:delete_person(this,' + id + ')" style="cursor:pointer; color:#D8000C;text-align: center;"></i></div>']);

  }
  //richiesta di modifica al server
  else if (action == 2) {

     id = data[0];
     nome = document.getElementById('name_column').value;
     cognome = document.getElementById('surname_column').value;
     //console.log(id + " " + nome + " " + cognome);
     $.ajax({
        type: "post",
        url: "users/admin/functions.php",
        dataType: 'html',
        cache: false,
        data: {
           function: 4,
           id: id,
           nome: nome,
           cognome: cognome,
        },
        success: function (data) {
           change_tab('tab1');//refreshes the page
        },
        error: function () {
           alert('Error while request..! try again');
        }
     });
  }
}


//delete a person
function delete_person(obj,id) { 

  $.ajax({
    type: "post",
    url: "users/admin/functions.php",
    dataType: 'html',
    cache: false,
    data: {
       function: 5,
       id: id
    },
    success: function (data) {
       //change_tab('tab1');//refreshes the page
    },
    error: function () {
       alert('Error while request..! try again');
    }
 });
}

