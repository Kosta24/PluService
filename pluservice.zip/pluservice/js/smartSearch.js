var input = document.getElementById("add_city");
var list = document.getElementById("items-list");
if (input)
  input.addEventListener("keyup", (e) => {
    //loop through above array
    //Initially remove all elements ( so if user erases a letter or adds new letter then clean previous outputs)

    send_suggestions();

  });


//takes suggestions from the server
function send_suggestions() {
  if (input.value != "")
    $.ajax({
      type: "post",
      url: "/pluservice/it/home/users/admin/functions.php",
      dataType: 'json',
      cache: false,
      data: {
        function: 6,
        written: input.value,
        limit: 10,
      },
      success: function (returnedData) {
        removeElements();
        if (returnedData != "") {
          var options = [];
          //console.log(returnedData);
          for (var i = 0; i < returnedData.length; i++) options.push(returnedData[i]["name"]);
          //console.log(options);
          addElements(options);//makes the smartsearch results visible
        }
      },
      error: function () {
        alert('Error while request..! try again');
      }
    });
  else
    removeElements();
}

function addElements(array) {

  for (let i of array) {
    //convert input to lowercase and compare with each string
    //i.toLowerCase().startsWith(input.value.toLowerCase()) && 
    if (input.value != "") {
      //create li element
      let listItem = document.createElement("li");
      //One common class name
      listItem.style.cursor = "pointer";
      listItem.classList.add("list-items");

      //listItem.classList.add("img-clck");
      listItem.setAttribute("onclick", "displayNames('" + i + "')");//"displayNames('" + i + "')"
      listItem.setAttribute("id", "list-items");
      //Display matched part in bold
      let word = "<b>" + i.substr(0, input.value.length) + "</b>";
      word += i.substr(input.value.length);
      //display the value in array
      listItem.innerHTML = word;
      document.querySelector(".list").appendChild(listItem);
      listItem.addEventListener("click", (e) => {
        displayNames(i);
      });
    } else
      removeElements();
  }


};



function displayNames(value) {
  input.value = value;

  //console.log("sent");
  removeElements();
}

function removeElements() {
  //clear all the item
  let items = document.querySelectorAll(".list-items");
  items.forEach((item) => {
    item.remove();
  });
}


//check if it text is unfocussed and if item list isnt clicked


$(document).click(function (e) {
  if (!input.contains(e.target) && !list.contains(e.target)) {
    removeElements();
  }
});






/*document.getElementById("product_search_textbox").addEventListener("blur", (e) => {
  console.log("unfocus")
  //removeElements());
});*/

//aggiungi suggestions
$(document).on("click", "#add_city", function () {
  if ($(this).is(":focus")) {
    send_suggestions();
  }
});
