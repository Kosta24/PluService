
$(document).ready(function () {
  $(window).on('load', function () {
    setTimeout(function () {
    $('.preloader').addClass('complete');
    if ($('.preloader').hasClass('complete')) {
      $('.preloader.complete').find('.lds-ring').remove();
      $('.preloader.complete').find('img').remove();
      $(window).trigger('scroll');
    }
    change_tab("tab1");
  }, 10);

  })//END LOAD

})

