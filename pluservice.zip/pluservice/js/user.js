
function change_tab(pagina) {
  $.ajax({
    type: "post",
    url: "users/user/pages.php",
    dataType: 'html',
    cache: false,
    data: {
      get_this: pagina,
    },
    success: function (data) {
      if (data != "") {
        $('#tab-wrapper').html("");
        $('#tab-wrapper').html(data);
      }

    },
    error: function () {
      alert('Error while request..! try again');
    }
  });
  return false;
}

//Loads cities gradually
function print_humans() {
  show_humans(15);
  setTimeout(function () { show_humans(25) }, 100);
  setTimeout(function () { show_humans(100) }, 250);
  setTimeout(function () { show_humans(0) }, 750);
}

//Loads cities gradually
function print_cities() {
  show_cities(15);
  setTimeout(function () { show_cities(25) }, 100);
  setTimeout(function () { show_cities(100) }, 250);
  setTimeout(function () { show_cities(0) }, 750);
}

//Populates the table with cities from the DB
function show_humans(limit) {
  $.ajax({
    type: "post",
    url: "users/user/functions.php",
    dataType: 'json',
    cache: false,
    data: {
      function: 1,
      limit: limit,
    },
    success: function (returnedData) {
      //console.log(returnedData);

      var table = $('#table_humans').DataTable();
      table.clear();

      var myTableArray = [];
      var result = returnedData;

      for (var i = 0; i < result.length; i++) {
        myTableArray.push([result[i]["id"], result[i]["nome"], result[i]["cognome"], result[i]["city"]])
      }

      table.rows.add(myTableArray);
      table.column(0).visible(false);
      table.draw(false);
    },
    error: function () {
      alert('Error while request..! try again');
    }
  });
}

//Populates the table with cities from the DB
function show_cities(limit) {
  $.ajax({
    type: "post",
    url: "users/user/functions.php",
    dataType: 'json',
    cache: false,
    data: {
      function: 2,
      limit: limit,
    },
    success: function (returnedData) {
      //console.log(returnedData);

      var table = $('#table_cities').DataTable();
      table.clear();

      var myTableArray = [];
      var result = returnedData;
      for (var i = 0; i < result.length; i++) {
        myTableArray.push([result[i]["id"], result[i]["name"]])
      }

      table.rows.add(myTableArray);
      //table.column(3).visible(false);
      table.draw(false);
    },
    error: function () {
      alert('Error while request..! try again');
    }
  });
}

//Inizialize the Cities Datatable
function init_datatable_humans() {
  $("#table_humans thead tr").addClass("filters").appendTo("#table_humans thead");

  var table = $("#table_humans").DataTable({
    "pageLength": 25,
    "order": [
      [0, "asc"]
    ],
    orderCellsTop: true,
    fixedHeader: true,
    fixedHeader: {
      header: true,
      footer: true
    },
    colReorder: false,
    scrollY: 700,
    scrollCollapse: true,
    scroller: true,
    dom: 'Bfrtip',
    buttons: [
      'copy', 'csv', 'excel', 'pdf', 'print'
    ],

  });
  return table;
}



//Inizialize the Cities Datatable
function init_datatable_cities() {
  $("#table_cities thead tr").addClass("filters").appendTo("#table_cities thead");

  var table = $("#table_cities").DataTable({
    "pageLength": 25,
    "order": [
      [0, "asc"]
    ],
    orderCellsTop: true,
    fixedHeader: true,
    fixedHeader: {
      header: true,
      footer: true
    },
    colReorder: false,
    scrollY: 700,
    scrollCollapse: true,
    scroller: true,
    dom: 'Bfrtip',
    buttons: [
      'copy', 'csv', 'excel', 'pdf', 'print'
    ],

  });
  return table;
}



