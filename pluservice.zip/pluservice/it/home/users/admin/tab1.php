<link rel="stylesheet" href="/pluservice/css/smartSearch.css">
<?php
$name = $surname = $city = "";
$name_err = $surname_err = $city_err = "";
?>
<div>
  <form id="person-form" class="col text-center" autocomplete="off">
    <br>
    &nbsp;<span style="font-size: 20px; font-weight: bold; font-family: RedHat">Aggiungi una nuova persona</span><br>
    <br>
    <input id="add_name" type="text" placeholder="Nome" value=<?php if (isset($_SESSION["add_name"]))    echo '"' . $_SESSION["add_name"] . '"' ?>></input>
    <input id="add_surname" type="text" placeholder="Cognome" value=<?php if (isset($_SESSION["add_surname"])) echo '"' . $_SESSION["add_surname"] . '"' ?>></input>
    <input id="add_city" type="text" placeholder="Città" value=<?php if (isset($_SESSION["add_city"]))    echo '"' . $_SESSION["add_city"] . '"' ?>></input>

    <button type="button" class="btn btn-primary" onclick=" add_person()">Aggiungi</button>
    <div class="smart-search-container  col text-center">
      <ul class="list" id="items-list"></ul>
    </div>


    <span style="font-size: 15px; font-weight: bold; font-family: RedHat">
      <?php
      if (isset($_SESSION["add_name"])) unset($_SESSION["add_name"]);
      if (isset($_SESSION["add_surname"])) unset($_SESSION["add_surname"]);
      if (isset($_SESSION["add_city"])) unset($_SESSION["add_city"]);
      if (isset($_SESSION["risposta_add"])) {
        echo $_SESSION["risposta_add"];
        unset($_SESSION["risposta_add"]);
      } else echo "&nbsp;"

      ?>
    </span>
  </form>

</div>

<div class="Datatable_container">
  <table class="Datatable_table" id='table_humans'>
    <thead>
      <tr>
        <th>Id</th>
        <th>Nome</th>
        <th>Cognome</th>
        <th>Città</th>
        <th style="text-align: center;">Modifica</th>
        <th style="text-align: center;">Rimuovi</th>
      </tr>
    </thead>
    <tbody>
    </tbody>
    <tfoot>
    </tfoot>
  </table>
</div>
<script>
  init_datatable_humans(); //Inits the table with basic informations
  print_humans(); //Populates the table
  modificando = -1; //Flag for modification of the records
  $(document).ready(function() {
    $.getScript("/pluservice/js/smartSearch.js");
  });
</script>