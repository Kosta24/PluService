<?php
// Include config file
require_once "../../../../config.php";
if (session_status() === PHP_SESSION_NONE) {
  session_start();
}



function getHumans()
{
  global $link;

  //check if the limit is an integer
  if (!is_int($_POST['limit']) != "integer") $_POST['limit'] = 0;
  if ($_POST['limit'] == 0) $_POST['limit'] = "999999999";


  $sql = "SELECT people.id,people.nome,people.cognome,cities.name as city from people
            INNER JOIN cities on cities.id = people.fk_city  Limit ?";

  //Escapesc the string just in case
  $limit = mysqli_real_escape_string($link, $_POST['limit']);

  $stmt = $link->prepare($sql);
  $stmt->bind_param("i", $limit);
  $stmt->execute();
  $result = $stmt->get_result();
  $array = $result->fetch_all(MYSQLI_ASSOC);
  mysqli_close($link);
  return json_encode($array);
}

function getCities()
{
  global $link;

  //check if the limit is an integer
  if (!is_int($_POST['limit']) != "integer") $_POST['limit'] = 0;
  if ($_POST['limit'] == 0) $_POST['limit'] = "999999999";


  $sql = "SELECT * from cities Limit ?";

  //Escapesc the string just in case
  $limit = mysqli_real_escape_string($link, $_POST['limit']);

  $stmt = $link->prepare($sql);
  $stmt->bind_param("i", $limit);
  $stmt->execute();
  $result = $stmt->get_result();
  $array = $result->fetch_all(MYSQLI_ASSOC);
  mysqli_close($link);
  return json_encode($array);
}

function addPerson()
{
  global $link;

  //Escapesc the string just in case
  $name = mysqli_real_escape_string($link, $_POST['name']);
  $surname = mysqli_real_escape_string($link, $_POST['surname']);
  $city = mysqli_real_escape_string($link, $_POST['city']);

  $_SESSION["add_name"]    = $name;
  $_SESSION["add_surname"] = $surname;
  $_SESSION["add_city"]    = $city;

  if (empty($name) || empty($surname) || empty($city)) {
    $_SESSION["risposta_add"] = "Completare tutti i campi!";
    mysqli_close($link);
    return;
  }

  $sql = "INSERT into people (nome, cognome, fk_city) values (?,?,(SELECT id from cities where name = ? limit 1))";



  $stmt = $link->prepare($sql);
  $stmt->bind_param("sss", $name, $surname, $city);
  $stmt->execute();
  mysqli_close($link);
  $_SESSION["risposta_add"] = "Utente aggiunto correttamente!";

  $_SESSION["add_name"]    = "";
  $_SESSION["add_surname"] = "";
  $_SESSION["add_city"]    = "";

  return;
}

function modifyPerson()
{
  global $link;

  $sql = "UPDATE people SET
          nome = ?,
          cognome = ?
          WHERE id = ?";

  //Escapesc the string just in case
  $nome = mysqli_real_escape_string($link, $_POST['nome']);
  $cognome = mysqli_real_escape_string($link, $_POST['cognome']);
  $id = mysqli_real_escape_string($link, $_POST['id']);

  $stmt = $link->prepare($sql);
  $stmt->bind_param("ssi", $nome, $cognome, $id);
  $stmt->execute();
  mysqli_close($link);
  return;
}

function deletePerson()
{
  global $link;

  $sql = "DELETE FROM people WHERE id = ?";

  //Escapesc the string just in case
  $id = mysqli_real_escape_string($link, $_POST['id']);

  $stmt = $link->prepare($sql);
  $stmt->bind_param("i", $id);
  $stmt->execute();
  mysqli_close($link);
  return;
}

function smartSearch()
{
  global $link;
  $array = array();

  if (!is_int($_POST['limit']) != "integer") $_POST['limit'] = 0;
  if ($_POST['limit'] == 0) $_POST['limit'] = "999999999";


  $sql = "SELECT name, LENGTH(name) as lun from cities
              where LOCATE(?,name) > 0
          group by name
          order by  lun asc,name asc
          Limit ?";
          //ricerca per corrispondenza
          //ordine per lunghezza inferiore

  $limit = mysqli_real_escape_string($link, $_POST['limit']);
  $written = mysqli_real_escape_string($link, $_POST["written"]);

  $stmt = $link->prepare($sql);
  $stmt->bind_param("si", $written,$limit);
  $stmt->execute();
  $result = $stmt->get_result();
  $array = $result->fetch_all(MYSQLI_ASSOC);
  mysqli_close($link);
  return json_encode($array);
}

//uso else if anzichè switch case solo perchè mi piace così compatto
if ($_POST["function"] == 1) echo getHumans();
else if ($_POST["function"] == 2) echo getCities();
else if ($_POST["function"] == 3) echo addPerson();
else if ($_POST["function"] == 4) echo modifyPerson();
else if ($_POST["function"] == 5) echo deletePerson();
else if ($_POST["function"] == 6) echo smartSearch();
