<div class="Datatable_container">
  <table class="Datatable_table" id='table_humans'>
    <thead>
      <tr>
        <th>Id</th>
        <th>Nome</th>
        <th>Cognome</th>
        <th>Città</th>
      </tr>
    </thead>
    <tbody>
    </tbody>
    <tfoot>
    </tfoot>
  </table>
</div>
<script>
  init_datatable_humans(); //Inits the table with basic informations
  print_humans(); //Populates the table
</script>