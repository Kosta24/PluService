<?php 
// Redirect to login page
header("location: ../");
exit;
?>