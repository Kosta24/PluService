<script>
  /*change location based on the browser language*/
  var userLang = navigator.language || navigator.userLanguage;
  userLang = userLang.substr(3,5).toLowerCase();

  //dict of available languages
  var langs = {
    "it":"it"
  }

  if(langs[userLang] !== undefined)location.href = langs[userLang];//if the nation exists then the language is selected
  else location.href = "en"; //else english is selected as default language

  //the two lines below should be implemented in any of the subdirectories
  //if (userLang == "fr" && window.location.href.includes("/en/")) location.href = window.location.href.replace("/en/", "/fr/")
  //else if (userLang != "fr" && window.location.href.includes("/fr/")) location.href = window.location.href.replace("/fr/", "/en/")
</script>