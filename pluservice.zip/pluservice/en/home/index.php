<?php
//Checks if the session exists, if not it proceeds to create it
if (session_status() === PHP_SESSION_NONE) {
  session_start();
}

// Check if the user is already logged in, if yes then redirect him to welcome page
if (!isset($_SESSION["username"])) {
  header("location: ../");
  exit;
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <title>PluService</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="icon" href="https://www.pluservice.net/wp-content/themes/pluservice/iconwebdark.jpg" type="image/png">

  <link rel="stylesheet" href="/pluservice/libs/bootstrap5/css/bootstrap.min.css">
  <link rel="stylesheet" href="/pluservice/libs/datatables/datatables.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css">
  <link rel="stylesheet" href="/pluservice/libs/clean-sidebar/style.css">

  <link rel="stylesheet" href="/pluservice/css/index.css">

</head>

<body>
  <!--Begin Loading overlay-->
  <div class="preloader">
    <img class="loadingimg" src="https://www.pluservice.net/wp-content/themes/pluservice/img/logoloading.png">
    <div class="lds-ring">
      <div></div>
      <div></div>
      <div></div>
    </div>
  </div>
  <!--End Loading overlay-->

  <!--Begin Main Window Wrapper-->
  <div class="task-manager glass">
    <?php
    //Loads the sidebar based on the user grade
    if ($_SESSION["grade"] == 1)
      include "users/user/sidebar.php"; //Loads the user sidebar
    else if ($_SESSION["grade"] == 10)
      include "users/admin/sidebar.php"; //Loads the admin sidebar
    ?>

    <!--Begin Dynamic Tab-->
    <div id="tab-wrapper">

    </div>
    <!--End Dynamic Tab-->

  </div>
  <!--End Main Window Wrapper-->

  <script src="/pluservice/libs/jquery/jquery-3.6.1.slim.min.js" type="text/javascript"></script>
  <script src="/pluservice/libs/bootstrap5/js/bootstrap.bundle.min.js" type="text/javascript"></script>
  <script src="/pluservice/libs/datatables/datatables.min.js" type="text/javascript"></script>
  
  <script src="https://kit.fontawesome.com/8d48ca70e8.js" crossorigin="anonymous"></script>
  <script src="/pluservice/js/index.js" crossorigin="anonymous"></script>
  
</body>

</html>