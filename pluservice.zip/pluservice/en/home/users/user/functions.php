<?php 
// Include config file
require_once "../../../../config.php";
if (session_status() === PHP_SESSION_NONE) {
  session_start();
}



function getHumans()
{
  global $link;

  //check if the limit is an integer
  if(!is_int($_POST['limit']) != "integer") $_POST['limit'] = 0;
  if ($_POST['limit'] == 0) $_POST['limit'] = "999999999";
  

  $sql = "SELECT people.id,people.nome,people.cognome,cities.name as city from people
            INNER JOIN cities on cities.id = people.fk_city  Limit ?";

  //Escapesc the string just in case
  $limit = mysqli_real_escape_string($link,$_POST['limit']);

  $stmt = $link->prepare($sql);
  $stmt->bind_param("i",$limit );
  $stmt->execute();
  $result = $stmt->get_result();
  $array = $result->fetch_all(MYSQLI_ASSOC);
  mysqli_close($link);
  return json_encode($array);
}

function getCities()
{
  global $link;

  //check if the limit is an integer
  if(!is_int($_POST['limit']) != "integer") $_POST['limit'] = 0;
  if ($_POST['limit'] == 0) $_POST['limit'] = "999999999";
  

  $sql = "SELECT * from cities Limit ?";

  //Escapesc the string just in case
  $limit = mysqli_real_escape_string($link,$_POST['limit']);

  $stmt = $link->prepare($sql);
  $stmt->bind_param("i",$limit );
  $stmt->execute();
  $result = $stmt->get_result();
  $array = $result->fetch_all(MYSQLI_ASSOC);
  mysqli_close($link);
  return json_encode($array);
}


if ($_POST["function"] == 1) echo getHumans();
else if ($_POST["function"] == 2) echo getCities();