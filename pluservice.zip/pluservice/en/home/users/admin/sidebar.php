<script src="/pluservice/js/admin.js" crossorigin="anonymous"></script>
<div class="left-bar glass">
  <div class="upper-part ">
    <div class="actions">
      <div class="circle"></div>
      <span class="clean-grade">Admin</span>
      <div class="circle-2"></div>
    </div>
  </div>

  <div class="left-content ">
    <ul class="navbar__menu">
      <li class="navbar__item">
        <a  onclick="return change_tab('tab1');" class="navbar__link"><i class="fa-solid fa-user-group"></i></i><span>People</span></a>
      </li>
      <li class="navbar__item">
        <a  onclick="return change_tab('tab2');" class="navbar__link"><i class="fa-solid fa-city"></i><span>Cities</span></a>
      </li>

      <li class="navbar__item">
        <a  href="logout.php" class="navbar__link"><i class="fa-solid fa-sign-out "></i><span>Logout</span></a>
      </li>
      <!-- futura implementazione-->
      <!--
      <li class="navbar__item">
        <a  onclick="return change_tab('tab3');" class="navbar__link"><i class="fa-solid fa-scroll"></i><span>Logs</span></a>
      </li>
      -->
    </ul>
  </div>
</div>