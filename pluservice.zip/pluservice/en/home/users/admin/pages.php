<?php
//superAdmin
if (session_status() === PHP_SESSION_NONE) {
  session_start();
}

//Loads first tab
if (isset($_POST['get_this']) &&  $_POST['get_this'] == "tab1") {
  $_SESSION["tab"] = $_POST['get_this'];
  include "tab1.php";
}

//Loads second tab
if (isset($_POST['get_this']) && $_POST['get_this'] == "tab2") {
  $_SESSION["tab"] = $_POST['get_this'];
  include "tab2.php";
}

//Loads third tab
if (isset($_POST['get_this']) && $_POST['get_this'] == "tab3") {
  $_SESSION["tab"] = $_POST['get_this'];
  include "tab3.php";
}
