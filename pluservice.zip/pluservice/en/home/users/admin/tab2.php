<div class="Datatable_container">
  <table class="Datatable_table" id='table_cities'>
    <thead>
      <tr>
        <th>Id</th>
        <th>Name</th>
      </tr>
    </thead>
    <tbody>
    </tbody>
    <tfoot>
    </tfoot>
  </table>
</div>
<script>
  init_datatable_cities(); //Inits the table with basic informations
  print_cities();          //Populates the table
</script>