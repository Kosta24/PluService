<?php
// Initialize the session
if (session_status() === PHP_SESSION_NONE) {
  session_start();
}

// Check if the user is already logged in, if yes then redirect him to welcome page
if (isset($_SESSION["username"])) {
  header("location: ../");
  exit;
}

// Include config file
require_once "../../config.php";

// Define variables and initialize with empty values
$name = $username = $password = "";
$username_err = $password_err = $login_err = "";

// Processing form data when form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {

  // Check if username is empty
  if (empty(trim($_POST["username"]))) {
    $username_err = "Please enter username.";
  } else {
    $username = trim($_POST["username"]);
  }

  // Check if password is empty
  if (empty(trim($_POST["password"]))) {
    $password_err = "Please enter your password.";
  } else {
    $password = trim($_POST["password"]);
  }

  // Validate credentials
  if (empty($username_err) && empty($password_err)) {
    // Prepare a select statement
    $sql = "SELECT id, username, hashed_password,salt, grade FROM users WHERE username = ?";

    if ($stmt = mysqli_prepare($link, $sql)) {
      // Bind variables to the prepared statement as parameters
      mysqli_stmt_bind_param($stmt, "s", $param_username);

      // Set parameters
      $param_username = $username;

      // Attempt to execute the prepared statement
      if (mysqli_stmt_execute($stmt)) {
        // Store result
        mysqli_stmt_store_result($stmt);

        // Check if username exists, if yes then verify password
        if (mysqli_stmt_num_rows($stmt) == 1) {
          // Bind result variables
          mysqli_stmt_bind_result($stmt, $id, $username, $hashed_password, $salt, $grade);
          if (mysqli_stmt_fetch($stmt)) {
            if (password_verify($password . $salt, $hashed_password)) {
              // Password is correct, so start a new session
              if (!isset($_SESSION)) {
                session_start();
              }

              // Store data in session variables
              $_SESSION["id"] = $id;
              $_SESSION["username"] = $username;
              $_SESSION["grade"] = $grade;

              header("location: ../");
              exit;
            } else {
              // Password is not valid, display a generic error message
              $login_err = "Invalid username or password.";
            }
          }
        } else {
          // Username doesn't exist, display a generic error message
          $login_err = "Invalid username or password.";
        }
      } else {
        echo "Oops! Something went wrong. Please try again later.";
      }

      // Close statement
      mysqli_stmt_close($stmt);
    }
  }

  // Close connection
  mysqli_close($link);
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <title>PluService</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="icon" href="https://www.pluservice.net/wp-content/themes/pluservice/iconwebdark.jpg" type="image/png">

  <link rel="stylesheet" href="/pluservice/css/login.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css">


</head>

<body>
  <!-- just a simple form-->
  <div class="form">
    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
      <span class="dot1">
        <div class="pro-img"><img class="pro-img" src="https://www.pluservice.net/wp-content/themes/pluservice/iconwebdark.jpg" alt="user"></div>
      </span>
      <h2>Login</h2>

      <label for="username">Username</label>
      <div class="input-box">
        <ion-icon name="person-outline"></ion-icon>
        <input type="text" id="username" name="username" class="form-control <?php echo (!empty($username_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $username; ?>">

      </div>
      <span style="color:#cc0000 ; top: -30%" class="invalid-feedback"><?php echo $username_err; ?></span></br>

      <label for="password">Password</label>
      <div class="input-box">

        <ion-icon class="prefix" name="lock-closed-outline"></ion-icon>

        <input autocomplete="true" type="password" id="id_password" name="password" class="form-control <?php echo (!empty($password_err)) ? 'is-invalid' : ''; ?>">

        <ion-icon class="switch-btn far fa-eye" name="eye-off-outline" id="togglePassword" style="top: -30%"> </ion-icon>

      </div>
      <span style="color:#cc0000 ; top: -30%" class="invalid-feedback"><?php echo $password_err; ?></span>

      <?php
      if (!empty($login_err)) {
        echo '<div style="color:#cc0000" class="alert alert-danger">' . $login_err . '</div>';
      }
      ?>

      <input type="submit" class="send-btn" value="Login">
    </form>
  </div>


  <script>
    const togglePassword = document.querySelector('#togglePassword');
    const password = document.querySelector('#id_password');

    togglePassword.addEventListener('click', function(e) {
      // toggle the type attribute
      const type = password.getAttribute('type') === 'password' ? 'text' : 'password';
      password.setAttribute('type', type);
      // toggle the eye slash icon
      this.classList.toggle('fa-eye-slash');
    });
  </script>
</body>

</html>